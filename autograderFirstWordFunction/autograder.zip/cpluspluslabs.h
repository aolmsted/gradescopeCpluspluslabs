#include <string>
using namespace std;
string firstword(string s);