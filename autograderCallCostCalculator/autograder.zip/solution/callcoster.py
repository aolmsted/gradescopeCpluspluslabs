day = input("Enter the day the call started at: ")
start_time = input("Enter the time the call started at (hhmm): ")
duration = input("Enter the duration of the call (in minutes): ")
if day.lower().startswith("sat") or day.lower().startswith("sun"):
    rate = .15
elif start_time >= "0800" and start_time <= "1800": 
    rate = .40
else:
    rate = .25
total = rate * int(duration)
print("This call will cost ${0:2.2f} ".format(total))