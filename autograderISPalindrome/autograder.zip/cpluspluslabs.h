bool is_palindrome(int test);
