int avgoflst(int lst[], int size);
