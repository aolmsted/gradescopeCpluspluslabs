float avgoflst(int lst[], int size);
