first = float(input("Enter price of the first item: "))
second = float(input("Enter price of the second item: "))
club = input("Does customer have a club card? (Y/N): ")
tax = float(input("Enter tax rate, e.g. 5.5 for 5.5% tax: "))
if first < second:
    lower = first
    higher = second
else:        
    lower = second
    higher = first
    
if club.lower().startswith("y"):
    discount = (lower/2 + higher) * .1
else:
    discount = 0
print("Base price = {0:2.2f} ".format(first + second))
print("Price after discounts = {0:2.2f} ".format(lower/2 + higher - discount))
total = round((lower/2 + higher - discount) * (1 + tax/100),2)
print("Total price = {0:2.2f} ".format(total))
