int gcd(int a, int b);
