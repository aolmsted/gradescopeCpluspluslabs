#include <iostream> 
#include <algorithm>  

int gcd(int a, int b)  
{ 
    return __gcd(a, b); 
} 