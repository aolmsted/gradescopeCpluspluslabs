using namespace std;
void csv_export(string data[10][10], int rows, int columns, string filename);
void csv_import(string data[10][10], int columns, int *records, string filename);

