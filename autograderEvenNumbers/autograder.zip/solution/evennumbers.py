num = int(input("Please enter a positive integer: "))
for x in range(num):
    print("{0}".format((x + 1)* 2))
