int maxabsinlst(int lst[], int size);
