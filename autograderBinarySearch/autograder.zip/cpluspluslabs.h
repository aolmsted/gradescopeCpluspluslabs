int binary_search(int search_value, int lst[], int elements);
