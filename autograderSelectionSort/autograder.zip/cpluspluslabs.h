void swap(int *xp, int *yp) ;
void selection_sort(int arr[], int elements);
