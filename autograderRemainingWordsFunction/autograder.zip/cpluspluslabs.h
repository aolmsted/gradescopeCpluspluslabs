#include <string>
using namespace std;
string remainingwords(string s);