#include <stdio.h>
#include <stdlib.h>
#include <string>
using namespace std;
class BST
{
  public:
    int data;
    BST *left, *right;

     BST() { data = 0;left = right = NULL;}
     BST(int x) { data = x;left = right = NULL;}
     BST* Insert(BST *, int);
     int nth_node(BST *, int n);
};

