instr = input("Enter an odd length string: ")
mid = len(instr) // 2
print("Middle character: {0} ".format(instr[mid]))
print("First half: {0} ".format(instr[:mid]))
print("Second half: {0} ".format(instr[mid+1:]))
