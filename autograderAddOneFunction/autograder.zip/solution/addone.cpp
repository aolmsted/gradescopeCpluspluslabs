#include <stdio.h>
#include <stdlib.h>

void addOne(int *ptrNum)
{
  *ptrNum++;  
}