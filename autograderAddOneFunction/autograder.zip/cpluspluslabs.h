void addOne(int *ptrNum);
