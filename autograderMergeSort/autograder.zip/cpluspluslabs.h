void merge(int arr[], int left, int middle, int right);
void merge_sort(int arr[], int left, int right);
