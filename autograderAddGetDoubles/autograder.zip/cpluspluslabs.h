double* getDoubles(int numDoubles);
