void merge(int arr[], int left, int middle, int right);
