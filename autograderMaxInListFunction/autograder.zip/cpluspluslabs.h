int maxinlst(int lst[], int size);
