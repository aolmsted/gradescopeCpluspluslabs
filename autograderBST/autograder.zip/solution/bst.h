#include <stdio.h>
#include <stdlib.h>
#include <string>
using namespace std;
class BST
{
  public:
    int data;
    BST *left, *right;

     BST() { data = 0;}
     BST(int x) { data = x;}
     BST* Insert(BST *, int);
     int nth_node(BST *, int n);
};

