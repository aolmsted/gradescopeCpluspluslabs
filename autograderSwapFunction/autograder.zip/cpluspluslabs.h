void swap(int *xp, int *yp) ;
